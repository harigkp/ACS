<?php 

namespace App\Models;
class User
{

        static function checkEmail($email,$conn)
        {
           echo $email = trim($email);
		   
		    $fetch_user_by_email = "SELECT id FROM `users` WHERE `email`='".$email."'";
            $query_stmt = $conn->prepare($fetch_user_by_email);
			
			echo "<pre>";
			print_r($query_stmt);
			
			
			echo $query_stmt->rowCount(); die;
        }


        function setUsername($username)
        {
            $this->username = $username;
        }

        
}

