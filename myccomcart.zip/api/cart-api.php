<?php
	
/* File : cart-api.php
	 * Author : Hari Ram Sharma
	*/
    //namespace App\Controllers\Frontend;
	ini_set("memory_limit","256M");
	ini_set('max_execution_time', 12000);
	
	use App\Controllers\Frontend\HomeController;
	
 	use Carbon\Carbon;
	use App\Models\User;
	use App\Models\Product;
	use App\Models\Category;
	
	use App\Helpers\ValidatorFactory;
	use PHPMailer\PHPMailer\Exception;
	use PHPMailer\PHPMailer\PHPMailer;
	
    use Firebase\JWT\JWT;
    require __DIR__ . '/../vendor/autoload.php';
	header("Access-Control-Allow-Origin: *");
	header("Content-Type: application/json; charset=UTF-8");
	header("Access-Control-Allow-Methods: POST");
	header("Access-Control-Max-Age: 3600");
	header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
	

	
	require_once("Rest.inc.php");
	require_once("api.php");

//ini_set("error_log", "/tmp/php-error_cart.log");	
	class API extends REST {

		
		public function __construct()
		{
			
			parent::__construct();	
			require 'db_connection.php';
            

		 // set your default time-zone
        date_default_timezone_set('Asia/Kolkata');
        $this->issuedAt = time();
        // Token Validity (3600 second = 1hr)
        $this->expire = $this->issuedAt + 3600;
        // Set your secret or signature
        $this->jwt_secrect = "this_is_my_secrect";
			
		}
		
		/*
		 * Public method for access api.
		 * This method dynmically call the method based on the query string
		 *
		 */
		public function processApi(){
			
			$func = strtolower(trim(str_replace("/","",$_REQUEST['rquest'])));

			if((int)method_exists($this,$func) > 0)
			{
				$this->$func();
			}
			else
			{
				$this->response('',404);				// If the method not exist with in this class, response would be "Page not found".
			}
		}
		
		function msg($success,$status,$message,$extra = []){
				return array_merge([
					'success' => $success,
					'status' => $status,
					'message' => $message
				],$extra);
		}


		/* This is API Login */	
		
		function login(){

			header("Access-Control-Allow-Origin: *");
			header("Access-Control-Allow-Headers: access");
			header("Access-Control-Allow-Methods: POST");
			header("Content-Type: application/json; charset=UTF-8");
			header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
			require 'db_connection.php';

			
			$db_connection = new Database();
            $conn = $db_connection->dbConnection();
			$config = new config_api;
			$result = file_get_contents('php://input');			

			$result = $config->jsondecode($result);

			$email=isset($result['email'])?$result['email']:'';
			$password=isset($result['password'])?$result['password']:'';
			//$User = new User;
			//echo "password----".$password; die; 
			if ($email==""){

				$outputdata = array( 'code' => '200','message' => 'Email cannot be blank .');							
				$this->response($config->json($outputdata), 200);
			}

			if ($password==""){

				$outputdata = array( 'code' => '200','message' => 'Password cannot be blank .');							
				$this->response($config->json($outputdata), 200);
			}
			
			
	$returnData = [];

	// IF REQUEST METHOD IS NOT EQUAL TO POST
	if($_SERVER["REQUEST_METHOD"] != "POST"):
		$returnData = msg(0,404,'Page Not Found!');

	// CHECKING EMPTY FIELDS
	elseif(!isset($email) 
		|| !isset($password)
		|| empty(trim($email))
		|| empty(trim($password))
		):

		$fields = ['fields' => ['email','password']];
		$returnData = $this->msg(0,422,'Please Fill in all Required Fields!',$fields);

	// IF THERE ARE NO EMPTY FIELDS THEN-
	else:
		$email = trim($email);
		$password = trim($password);

    // CHECKING THE EMAIL FORMAT (IF INVALID FORMAT)
    if(!filter_var($email, FILTER_VALIDATE_EMAIL)):
        $returnData = $this->msg(0,422,'Invalid Email Address!');


    // THE USER IS ABLE TO PERFORM THE LOGIN ACTION
    else:
        try{
            session_start();
            $fetch_user_by_email = "SELECT * FROM `users` WHERE `email`=:email";
            $query_stmt = $conn->prepare($fetch_user_by_email);
            $query_stmt->bindValue(':email', $email,PDO::PARAM_STR);
            $query_stmt->execute();

            // IF THE USER IS FOUNDED BY EMAIL
            if($query_stmt->rowCount()):
                $row = $query_stmt->fetch(PDO::FETCH_ASSOC);

                // VERIFYING THE PASSWORD (IS CORRECT OR NOT?)
                // IF PASSWORD IS CORRECT THEN SEND THE LOGIN TOKEN
                if(md5($password)==$row['password']):

                       
					$secret_key  = 'hari';
					$issuer_claim = 'http://localhost/'; 
					$audience_claim = 'ABCD';
					$issuedat_claim = time(); // issued at
					$notbefore_claim = $issuedat_claim + 10; //not before in seconds
					$expire_claim = $issuedat_claim + 120; // expire time in seconds
					$token = array(
							"iss" => $issuer_claim,
							"aud" => $audience_claim,
							"iat" => $issuedat_claim,
							"nbf" => $notbefore_claim,
							"exp" => $expire_claim,
							"data" => array(
								"id" =>  $row['id'],
								"name" => $row['name'],
								"admin" => $row['admin']
								)
							);
				
					http_response_code(200);
				
					$jwt = JWT::encode($token, $secret_key,'HS256');
              // echo $jwt; die;


                    $returnData = [
					    'code' => 200,
                        'admin' => $row['admin'],
						'success' => 1,
                        'message' => 'Successful login',
                        'token' => $jwt
                    ];
					
                    $_SESSION['success']  	= 'Welcome '.$row['name'].'.';
			    	$_SESSION['userid']  	= $row['id'];
					$_SESSION['admin']  	= $row['admin'];
			    	$_SESSION['login']  	= true; 
                // IF INVALID PASSWORD
                else:
                    $returnData = $this->msg(0,422,'Invalid Password!');
                endif;

            // IF THE USER IS NOT FOUNDED BY EMAIL THEN SHOW THE FOLLOWING ERROR
            else:
                $returnData = $this->msg(0,422,'Invalid Email Address!');
            endif;
        }
        catch(PDOException $e){
            $returnData = $this->msg(0,500,$e->getMessage());
        }

    endif;

endif;

echo json_encode($returnData);
			
			
			
}



 function checkUser(){
	$config = new config_api;
       ob_start();
       $headers = apache_request_headers();
	 
		header("Access-Control-Allow-Origin: *");
		header("Access-Control-Allow-Headers: access");
		header("Access-Control-Allow-Methods: GET");
		header("Content-Type: application/json; charset=UTF-8");
		header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

		require 'db_connection.php';
		


	$authHeader = $_SERVER['HTTP_AUTHORIZATION'];

		if ($authHeader=='') {
			$allHeaders = getallheaders();
			$authHeader = isset($allHeaders['Authorization']) ? $allHeaders['Authorization'] : false;
		}
	
	$arr = explode(" ", $authHeader);
	
     $secret_key  = 'hari';
	
	$jwt = $arr[1];

	
\Firebase\JWT\JWT::$leeway = 20;

if($jwt){

    try {

        $decoded = JWT::decode($jwt, $secret_key,array('HS256'));

		$outputdata = array( 'code' => '200','message' => 'Access granted');
		$this->response($config->json($outputdata), 200);	
        // Access is granted. Add code of the operation here 
		//$prresponse = "Access granted:";
       

    }catch (Exception $e){

		   // http_response_code(401);
			/*
			$prresponse['status']="FALSE";
			$prresponse['message'] = "Access denied";
			$prresponse['code'] = "401";
			$prresponse_json['json_data']=$prresponse;		
			$json_responsepr=json_encode($prresponse_json);
			echo $json_responsepr;
			$this->response($json_responsepr);	
			*/

			$outputdata = array( 'code' => '401','message' => 'Access denied');
			$this->response($config->json($outputdata), 200);	
		}

	} else {
		//http_response_code(401);
		/*
		$prresponse['status']="FALSE";
		$prresponse['message'] = "Access denied";
		$prresponse['code'] = "401";
		$prresponse_json['json_data']=$prresponse;		
		$json_responsepr=json_encode($prresponse_json);
		$this->response($json_responsepr);
	   */
		$outputdata = array( 'code' => '401','message' => 'Access denied');
		$this->response($config->json($outputdata), 200);
	}


	 
 }

		

	function register(){
		
		    $db_connection = new Database();
            $conn = $db_connection->dbConnection();
			echo "gvdgvdsgs";
			echo "<pre>";
			print_r($conn);
			echo "gvdgvdsgs";
			die;
			
			
			
			$config = new config_api;
			$result = file_get_contents('php://input');			

			$result = $config->jsondecode($result);
			
			
			$homecontroler = new HomeController();
			
			 $response = $homecontroler->register($result['username'],$result['email'],$result['Password'],$conn);
			
			echo "<pre>";
			print_r($response);
			die;
			
			
			
			

			/* $email=isset($result['email'])?$result['email']:'';
			$password=isset($result['password'])?$result['password']:''; */
	}




















		/* This is API Logout */	
		function logout(){
			
			$result = file_get_contents('php://input');
			$data = json_decode($result, TRUE);
			$config = new config_api;
			$gDbConn = $config->dbConnect();

			
			
			$job_id_check = "select '1' as check from service_job where job_id = :Varjob_id and api_init = :Varapi_init and source_ip = :Varsource_ip";
			
			$job_id_delete = "delete from service_job where job_id = :Varjob_id and api_init = :Varapi_init";
			
			
			
			if($data['job_id']<>"")
			{
				$bd['Varjob_id'] =$data['job_id'];
				$bd['Varapi_init'] ='customer';
				$bd['Varsource_ip'] = $config->getIp();

				
				$result4 = $gDbConn->Query($job_id_check, $bd);
				
				if(count($result4) > 0)
				{
				
				$bd['Varstatus'] = 1;
				
                $gDbConn->Execute( "UPDATE customer_start_end_api 
						                    SET
											 status = :Varstatus
											WHERE
                                               job_id = :Varjob_id", $bd);
					
					$result5 = $gDbConn->Execute($job_id_delete, $bd);
					$outputdata = array( 'code' => '200','message' => 'Logout');
				    $this->response($config->json($outputdata), 200);		
				}
				else
				{
					$outputdata = array( 'code' => '404','message' => 'Job ID not found');
				    $this->response($config->json($outputdata), 200);
				}
			}
			
		}


		
	}
	
	// Initiiate Library
	$api = new API;
	$api->processApi();
	
?>
