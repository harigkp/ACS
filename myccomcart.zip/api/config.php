<?php


//define('BASEPATH', '/var/www/hiregenics/hgcomply/');


$conf = array();
$conf['Database']['host']= 'localhost';
$conf['Database']['user']= 'root';
$conf['Database']['pwd']= '';
$conf['Database']['name']= 'composerecom';



?>