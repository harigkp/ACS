<?php

	/* File : api.php
	 * Author : Hari Ram Sharma
	*/
//ini_set("error_log", "/tmp/php-error_cart.log");
//use App\Models\User;
//require __DIR__ . '/JwtHandler.php';
	
	class config_api{
		
			protected $db;
			protected $headers;
			protected $token;
			

		
		function authentication($user,$pass)
		{
			
			require __DIR__.'/db_connection.php';
			
			$db_connection = new Database();
            $this->db = $db_connection->dbConnection();
			
			
			$user_name  = $user;
			$pass  = $pass;

				try {
					$fetch_user_by_id = "select id,name, email,email_verification_token,admin
					from users 
					where active = 1
					and email = '".$user_name."'
					and password = md5('".$pass."')	
			        ";
					$query_stmt = $this->db->prepare($fetch_user_by_id);
					$query_stmt->execute();

					if ($query_stmt->rowCount()) :
						return $query_stmt->fetch(PDO::FETCH_ASSOC);
					else :
						return false;
					endif;
				} catch (PDOException $e) {
					return null;
				}
			
		}





		/*
		 *	Encode array into JSON
		*/
		function json($data){
			if(is_array($data)){
				//return json_encode($data, JSON_UNESCAPED_SLASHES);
				return json_encode($data);
			}
		}
		
		
		function jsontimecard($data){
			if(is_array($data)){
				
				return str_replace('\\/', '/', json_encode($data));

			}
		}
				
		
		
		function jsondecode($data){

				return json_decode($data, JSON_UNESCAPED_SLASHES);
				//return json_encode($data);

		}
	

	}
?>
