		<footer class="footer mt-auto py-3">
		  	<div class="container">
		    	<span class="text-muted">&copy;<?php echo date('Y'); ?> E-Commerce Package - All right reserved by ACS.</span>
		  	</div>
		</footer>
		<script src="../node_modules/jquery/dist/jquery.min.js" type="text/javascript"></script>
		<script src="../node_modules/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
	</body>
</html>