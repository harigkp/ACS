<?php
$base_url = 'http://'.$_SERVER['HTTP_HOST'];
$api_login = 'http://'.$_SERVER['HTTP_HOST'].'/api/cart-api.php?rquest=login';
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>ACS E-COMMERCE</title>
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>/node_modules/bootstrap/dist/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>/assets/css/login.css">
</head>
<body>

	<div class="login-sidenav">
		<div class="login-main-text">
			<a class="py-2" href="/">
				<img src="https://acsicorp.com/wp-content/uploads/2021/06/ACS-Solutions-Registered-SVG-White.svg" width="124" height="40" ><title>Product</title>
			</a>
		   <h2>Application<br> Login</h2>
		   <p>Login or <a href="/register">Register</a> from here to access.</p>
		</div>
	</div>
	<div class="main-login-area">
		<div class="col-md-6 col-sm-12">

			<div class="session-msg mt-5">

				<?php partials('notifications'); ?>

				<?php if (isset($_SESSION['mailsend'])): ?>
					<div class="alert alert-success alert-dismissible fade show" role="alert">
					  	<span><?php echo $_SESSION['mailsend']; ?></span>
					  	<button type="button" class="close" data-dismiss="alert" aria-label="Close">
					    <span aria-hidden="true">&times;</span>
					  </button>
					</div>
				<?php endif;?>

			</div>

		    <div class="login-form">
		       <form action="" method="post">
		          <div class="form-group">
		             <label>User Email</label>
		             <input type="email" name="email" id="uemail" class="form-control rounded-0" placeholder="User Email">
		             <?php if (isset($_SESSION['login-email-error'])): ?>
		             	 <small class="form-text text-danger">
		             	 	<?php echo $_SESSION['login-email-error'][0]; ?>
		             	 </small>
		             <?php endif;?>
		          </div>
		          <div class="form-group">
		             <label>Password</label>
		             <input type="password" name="password" id="upassword" class="form-control rounded-0" placeholder="Password">
		             <?php if (isset($_SESSION['login-password-error'])): ?>
		             	 <small class="form-text text-danger">
		             	 	<?php echo $_SESSION['login-password-error'][0]; ?>
		             	 </small>
		             <?php endif;?>
		          </div>
		          <button type="button" class="btn btn-black rounded-0" onclick="return login();">Login</button>
		          <a href="/register" class="btn btn-default">Not member yet?</a><span id="loaderID" style="color:red;display:none;">Please wait<img src="<?php echo $base_url;?>/assets/images/loading.gif"/><span>
		       </form>
		    </div>
		</div>
	</div>
	<script src="../node_modules/jquery/dist/jquery.min.js" type="text/javascript"></script>
	<script src="../node_modules/bootstrap/dist/js/bootstrap.min.js" type="text/javascript"></script>
</body>
</html>

<script>




function login(){
	 /* Get from elements values */
 var u = $("#uemail").val();
 var p = $("#upassword").val();
 
 $('#loaderID').show();

 $.ajax({
        url: "<?php echo $api_login; ?>",
        type: "post",
        data: JSON.stringify({ 'email': u,'password': p }),
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (response) {
             $('#loaderID').hide();
           var objJSON = JSON.parse(JSON.stringify(response));
		   if(objJSON.code==200 && objJSON.message=="Successful login"){
			  if(objJSON.admin==1){
				   window.location.href = '<?php echo $base_url?>/dashboard';
			  }else{
				  window.location.href = '<?php echo $base_url?>/dashboard/orders';
				  
			  }
			  
			 
		   }
		   /* alert(objJSON.code); */
        },
        error: function(jqXHR, textStatus, errorThrown) {
           console.log(textStatus, errorThrown);
        }
    });
	
	
	
}
</script>