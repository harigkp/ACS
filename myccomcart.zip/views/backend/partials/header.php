<?php 
ob_start();
@session_start();
$base_url = 'http://'.$_SERVER['HTTP_HOST'];
$api_login = 'http://'.$_SERVER['HTTP_HOST'].'/api/cart-api.php?rquest=login';

	ini_set('max_execution_time','0'); 
	ini_set('max_input_time','0');
	require "vendor/autoload.php";
	use \Firebase\JWT\JWT;


$headers = apache_request_headers();

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: access");
header("Access-Control-Allow-Methods: GET");
//header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

	
//require 'api/db_connection.php';

/* unset($_SESSION['login']);
		unset($_SESSION['userid']);

		$_SESSION['success'] 	= 'You have been logout.';
		$_SESSION['error'] 		= NULL; */

/* $authHeader = $_SERVER['HTTP_AUTHORIZATION'];

if ($authHeader=='') {
	$allHeaders = getallheaders();
	$authHeader = isset($allHeaders['Authorization']) ? $allHeaders['Authorization'] : false;
}
echo "authHeader----".$authHeader; die;
$arr = explode(" ", $authHeader);

$secret_key  = 'hari';



\Firebase\JWT\JWT::$leeway = 20;
echo "jwt----".$jwt = $arr[1];
die; */
/* if($jwt){
	
 try {

      $decoded = JWT::decode($jwt, $secret_key,array('HS256'));

    }catch (Exception $e){


	session_start();
	unset($_SESSION['login']);
	unset($_SESSION['userid']);

	$_SESSION['success'] 	= 'You have been logout.';
	$_SESSION['error'] 		= NULL;

	header("Location:".$base_url.'/login');
}

} else {

	session_start();
	unset($_SESSION['login']);
	unset($_SESSION['userid']);

	$_SESSION['success'] 	= 'You have been logout.';
	$_SESSION['error'] 		= NULL;

	header("Location:".$base_url.'/login');
} */
	
//echo json_encode($auth->isValid());
?>

<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
        <meta name="generator" content="Jekyll v3.8.5">
        <title>ACS E-commerce</title>

        <link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>/node_modules/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo $base_url;?>/assets/css/dashboard.css">
    </head>
    <body>
        
    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
        <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="/dashboard">E-commerce</a>
        <ul class="navbar-nav px-3">
            <li class="nav-item text-nowrap">
                <a class="nav-link" href="/logout">Sign out</a>
            </li>
        </ul>
    </nav>