<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script>
    window.jQuery || document.write('<script src="../../../node_modules/jquery/dist/jquery.min.js"><\/script>')
</script>
<script src="../../../node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="../../../node_modules/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>
</html>