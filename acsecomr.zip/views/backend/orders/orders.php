
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3">
                <h1 class="h2">Orders &amp; Products</h1>
            </div>

            <div class="table-responsive">
                <table class="table table-bordered table-sm">
                    <thead>
                        <tr>
                        <th>#</th>
                        <th>Order ID</th>
                        <th>Product ID</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
						
						/* echo "<pre>";
						print_r($address); */
						
						
						
						foreach($orders as $order) : 
						
						$product = Product::find($order->product_id);
						echo "<pre>";
						print_r($product)
						
						?>
                        <tr>
                            <td><?php echo $order->id; ?></td>
                            <td><?php echo $order->order_id; ?></td>
                            <td><?php echo $order->product_id; ?></td>
                            <td><?php echo $order->quantity; ?></td>
                            <td><?php echo $order->price; ?></td>
                            
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
    