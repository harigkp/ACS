
    <script src="http://<?php echo $_SERVER['HTTP_HOST']?>/node_modules/jquery/dist/jquery.min.js"></script>

<script src="http://<?php echo $_SERVER['HTTP_HOST']?>/node_modules/bootstrap/dist/js/bootstrap.min.js"></script>
<script src="http://<?php echo $_SERVER['HTTP_HOST']?>/node_modules/feather-icons/dist/feather.min.js"></script>
<script>
    feather.replace()
</script>


</html>